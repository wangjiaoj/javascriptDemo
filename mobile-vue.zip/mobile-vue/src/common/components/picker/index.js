import { Picker } from 'vant'

export default Picker;
