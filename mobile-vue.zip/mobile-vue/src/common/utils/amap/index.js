import { requestJSONP } from '@utils/request';

// 根据高德经纬度获取位置信息
export function amapRegeo(locations) {
  return requestJSONP('https://restapi.amap.com/v3/geocode/regeo', {
    key: AMAP_KEY,
    location: locations
  });
}

// 坐标转换是一类简单的HTTP接口，能够将用户输入的非高德坐标（GPS坐标、mapbar坐标、baidu坐标）转换成高德坐标。
export function amapTrans(lat, lon) {
  return requestJSONP('https://restapi.amap.com/v3/assistant/coordinate/convert', {
    key: AMAP_KEY,
    locations: `${lon},${lat}`,
    coordsys: 'gps'
  });
}

// vanish定位转成高德定位
export async function vanishLoc2Amap(lat, lon) {
  return amapTrans(lat, lon).then(({ data: amapInfo }) => {
    if (amapInfo.status !== '1') {
      return;
    }

    return amapRegeo(amapInfo.locations).then(({ data: geoInfo }) => {
      if (geoInfo.status !== '1') {
        return;
      }

      return geoInfo;
    })
  })
}
