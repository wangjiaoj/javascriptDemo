<template lang="html">
  <div class="market-tab-bar">

    <a href="javascript:;" class="market-tab-bar-market" :class="{'tab-bar-active': 'index' === activeTab}">
        <router-link to="/market/index"> <span>沪深A股</span></router-link> 
    </a>
    <a href="javascript:;" class="market-tab-bar-commodity" :class="{'tab-bar-active': 'commodity' === activeTab}">
      <router-link to="/market/commodity">  <span>商品期货</span></router-link> 
    </a>
    <a href="javascript:;" class="market-tab-bar-stock" :class="{'tab-bar-active': 'stock' === activeTab}"  >
       <router-link to="/market/stock"> <span>股指期货</span></router-link> 
    </a>
    <a href="javascript:;" class="market-tab-bar-foreign" :class="{'tab-bar-active': 'foreign' === activeTab}"  >
       <router-link to="/market/foreign"> <span>外汇</span></router-link> 
    </a>
  </div>
</template>

<script>
 

export default {
  props: {
    activeTab: String
  },
  created() {
    
  },
  computed: {
    
     
  },
}
</script>

<style lang="less">
@import '~@style/init.less';

.market-tab-bar {
   
  width:100vw;
  
  font-size: 0;
  .px2rem(height, 40);
  .px2rem(line-height, 40);
  display: flex;
  justify-content: space-between;
  background-color: red;

  a {
    display: inline-block;
    text-align: center;
    .px2rem(font-size, 16);  
    color: #999;
      
    &.tab-bar-active span {
     color:#FFFFFF;
    }
  }

  
  
  

  
 

}
</style>
