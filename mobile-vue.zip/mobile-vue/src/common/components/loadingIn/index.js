import { Loading } from 'vant';

export default Loading;