function dataFormat(data) {
  if (data === 'false') {
    return false;
  } else if (data === 'null') {
    return null;
  } else {
    return data;
  }
}


export function sessionSetItem(key, value) {
  sessionStorage.setItem(key, value);
}

export function sessionGetItem(key) {
  return dataFormat(sessionStorage.getItem(key));
}

export function sessionClear() {
  sessionStorage.clear();
}

export function setSessionStorage(data) {
  Object.keys(data).forEach(key => {
    sessionStorage.setItem(key, data[key]);
  });
}

export function getSessionStorage(keys) {
  const result = Object.assign({}, keys);

  Object.keys(keys).forEach(key => {
    result[key] = dataFormat(sessionStorage.getItem(key));
  });

  return result;
}
