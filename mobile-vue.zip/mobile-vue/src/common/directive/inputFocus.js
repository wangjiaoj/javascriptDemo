export default {
  inserted(el, binding) {
    const inputEl = el.querySelector('input');
    inputEl.focus();
  }
}
