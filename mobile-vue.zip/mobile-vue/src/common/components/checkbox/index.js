 import { Checkbox } from 'vant';

 export default Checkbox;