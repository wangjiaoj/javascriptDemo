/** Vue注册request方法
/* 功能
/* 1. 重复请求取消上次请求
/* 2. 组件销毁和组件离开时取消请求
**/

import { request } from '@utils/request';

function install(Vue, options) {
  Vue.mixin({
    created() {
      this._cancelRequestAction = null;
    },
    destroyed() {
      this._cancelRequest();
    },
    deactivated() {
      this._cancelRequest();
    },
    methods: {
      _cancelRequest() {
        if (typeof this._cancelRequestAction === 'function') {
          this._cancelRequestAction();
        }
      },
      _setCancelRequestAction(c) {
        this._cancelRequest();
        this._cancelRequestAction = c;
      },
      $request(url, data, type, option, otherConfig) {
        return request(url, data, type, Object.assign({}, option, {
          cancelTokenCallback: this._setCancelRequestAction
        }), otherConfig)
      }
    }
  });

//   Vue.prototype.$request = function(url, data, type, option) {
//     this._isLoading = true;
// debugger;
//     const instance = request(url, data, type, Object.assign({}, option, {
//       cancelTokenCallback: this._setCancelRequestAction
//     }))
//
//     Promise.resolve(instance).then(() => {
//       this._isLoading = false;
//     })
//
//     return instance;
//   }
}

export default {
  install
}
