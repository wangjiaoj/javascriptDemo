 import { dateFormat } from '@utils/dater';

 export function dataFormat(data) {
     return Array.isArray(data) ? data.map(item => {
         //  let time = item.callStart ? dateFormat(new Date(parseInt(item.callStart)), 'yyyy-MM-dd hh:mm:ss') : '';
         return {
             stockName: item['10'],
             stockCode: item['5'],
             price: item['199112'],
             zdf: item['2558408'],
         }
     }) : []
 }
 export function dataFormatList(data) {
     return Array.isArray(data) ? data.map(item => {
         //  let time = item.callStart ? dateFormat(new Date(parseInt(item.callStart)), 'yyyy-MM-dd hh:mm:ss') : '';
         return {
             stockName: item['10'],
             stockCode: item['5'],
             price: item['199112'],
             zdf: item['2558408'],
         }
     }) : []
 }