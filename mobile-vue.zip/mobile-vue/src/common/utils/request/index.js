import axios from 'axios';
import jsonp from 'jsonp';
import qs from 'qs';

import toast from '@cc/toast';

// 参数过滤
function paramsFormat(data) {
    const params = {};
    Object.keys(data).forEach(key => {
        if (data[key] !== null && data[key] !== undefined && data[key] !== '') {
            params[key] = data[key];
        }
    });

    return params;
}

// 链接
export function urlFormat(url) {
    //const API_PATH = '"https://172.19.80.83:7443/new_jgbcrm_dev/ifindcrm"';
    //API_PATH + window.ctx + url
    return url;
}


// 请求
export function request(
    url,
    data = {},
    type = 'get',
    option = {
        errorTip: '',
        cancelTokenCallback: null
    },
    otherConfig = {}
) {
    url = urlFormat(url);

    // jsonp test
    // type = 'jsonp';

    let asyncFn = null;

    switch (type.toLowerCase()) {
        case 'get':
            asyncFn = requestGET(url, paramsFormat(data), option.cancelTokenCallback);
            break;
        case 'post':
            asyncFn = requestPOST(url, paramsFormat(data), option.cancelTokenCallback, otherConfig);
            break;
        case 'form':
            asyncFn = requestForm(url, data, option.cancelTokenCallback, otherConfig);
            break;
        case 'jsonp':
            asyncFn = requestJSONP(url, paramsFormat(data));
            break;
        default:
            console.error('type错误！');
    }

    return new Promise((resolve, reject) => {
        asyncFn.then(response => {
            const { data, ...otherInfo } = response;
            // debugger;
            switch (data.error) {
                case 1:
                    resolve({
                        ...data,
                        // data: data.data,
                        ...otherInfo
                    })
                    break;
                default:
                    reject({...data });
                    // 权限验证接口不做弹框限制
                    if (response.config.url.indexOf('vanishValidate') < 0) {
                        toast.fail(data.message || '失败');
                    }
            }
        }).catch(e => {
            if (axios.isCancel(e)) {
                console.log('请求被取消');
            } else {
                reject({
                    error: e
                });
                var configUrl = e.config.url.indexOf('?') > 0 ? e.config.url.split('?')[0] : e.config.url;
                if (configUrl.indexOf('/') > 0) {
                    let configUrlList = configUrl.split('/');
                    configUrl = configUrlList[configUrlList.length - 1];
                }
                var msg = option.errorTip ? (option.errorTip + ':' + configUrl) : ('接口出错:' + configUrl);
                toast.fail(msg);
            }
        });
    })

}

// get请求
export function requestGET(url, params, cancelTokenCallback) {
    params.fresh = new Date().getTime();
    return doAxios(url, params, 'get', cancelTokenCallback);
}

// post请求
export function requestPOST(url, params, cancelTokenCallback, otherConfig) {
    return doAxios(url, params, 'post', cancelTokenCallback, otherConfig);
}

// 表单提交
export function requestForm(url, params, cancelTokenCallback, otherConfig) {
    return doAxios(url, params, 'post', cancelTokenCallback, {
        ...otherConfig,
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    });
}

// jsonp请求
export function requestJSONP(url, params) {
    // params.fresh = new Date().getTime();

    const queryString = qs.stringify(params);

    const am = ~url.indexOf('?') ? '&' : '?';

    url = `${url}${queryString ? (am + queryString) : ''}`;

    return new Promise((resolve, reject) => {
        jsonp(url, {
            param: 'callback'
        }, (opt, response) => {
            resolve({
                data: response
            });
        })
    });
}


// export function downloadFile(url, params) {
//     url = urlFormat(url);
//
//     return new Promise((resolve, reject) => {
//         doAxios(url, params, 'post', null, {
//             responseType: 'blob'
//         }).then(({ data }) => {
//             // data = new Blob([data]);
//
//             const reader = new FileReader();
//             reader.addEventListener('abort', reject);
//             reader.addEventListener('error', reject);
//             reader.addEventListener('loadend', () => {
//                 resolve(reader.result);
//             });
//             reader.readAsText(data);
//         })
//     })
// }


// 发出axios请求
function doAxios(url, params, type, cancelTokenCallback, otherConfig) {
    const config = {
        url,
        method: type,
        withCredentials: true,
        params: type !== 'post' ? params : null,
        data: params instanceof FormData ? params : (type === 'post' ? qs.stringify(params) : null),
        ...otherConfig
    };

    if (typeof cancelTokenCallback === 'function') {
        const CancelToken = axios.CancelToken;
        config.cancelToken = new CancelToken(cancelTokenCallback);
    }


    return axios(config);
}