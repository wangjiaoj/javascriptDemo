<template lang="html">
  <div class="page-search">
       
    <div class="search-btn">搜索...</div>  
    <span class="search-cancel-btn">取消</span>  
    <!-- <a href="javascript:;" class="tab-bar-center" :class="{'tab-bar-active': 'center' === activeTab}"  >
       <router-link to="/center/index"><i></i> <span>个人中心</span></router-link> 
    </a> -->
     
  </div>
</template>

<script>
 
export default {
  props: {
    activeTab: String
  },
  components:{    
      'v-button': require('@cc/button').default,
  },
  created() {
    
  },
  computed: {
    
     
  },
}
</script>

<style lang="less">
@import '~@style/init.less';
 

 
.page-search {
    width:100vw;
    .px2rem(width, 375);
    .px2rem(height, 50);
    .px2rem(padding-top, 10);
    .px2rem(padding-bottom, 10);
    .px2rem(padding-left, 16);
    margin:0 auto;
   
    .px2rem(font-size, 14);
    justify-content: space-between;
    background-color: red;
     color: #000000;
    .search-btn{
       display:inline-block;
      .px2rem(height, 30);
      .px2rem(width, 296);
      .px2rem(line-height, 30);
       background-color: #FFF;

    }
    .search-cancel-btn{
      display:inline-block;
      .px2rem(font-size, 16);
      .px2rem(height, 30);
      .px2rem(line-height, 30);
      color: #FFF;
    }
}
</style>
