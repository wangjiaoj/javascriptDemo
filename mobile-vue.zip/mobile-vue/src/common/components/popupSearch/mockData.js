import { Mock, Random, wrap } from '@mock';

// 公司联想
Mock.mock(/\/company/, wrap({
  'rows|20': [{
    // 客户主键
    'custSeq|+1': 1,
    'text': () => Random.cword(8, 16)
  }]
}))
