<template lang="html">
  <div class='map-container'>
    <div class="map-mask" v-if="showOnly"></div>
    <div class="map-center-point" :class="{'map-jump': isJump}" ref="point" @animationend="jumpEnd">
      <img :src="img" alt="">
    </div>
    <div class="map" ref="map"></div>
  </div>
</template>

<script>
export default {
  props: {
    // 只读
    showOnly: {
      type: Boolean,
      default: false
    },
    page: {
      type: Number,
      default: 1
    },
    pagesize: {
      type: Number,
      default: 10
    },
    defaultPosition: null,
    showPosButton: {
      type: Boolean,
      default: true
    }
  },
  created() {
    this.img = require('@images/posi.png');
    // 地图实例
    this.mapInstance = null;
    this.geolocation = null;
  },
  mounted() {
    this.mapInstance = new AMap.Map(this.$refs.map, {
      resizeEnable: true,
      // zoom: 18
    });

    // 定位
    this.geolocation = new AMap.Geolocation({
      // 是否显示定位按钮
      showButton: this.showPosButton,
      //是否使用高精度定位，默认:true
      enableHighAccuracy: true,
      //是否使用高精度定位，默认:true
      timeout: 10000,
      //定位按钮的停靠位置
      buttonPosition:'RB',
      //定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
      buttonOffset: new AMap.Pixel(10, 20),
      //定位成功后是否自动调整地图视野到定位点
      zoomToAccuracy: true
    });
    this.mapInstance.addControl(this.geolocation);


    this.geolocation.on('complete', this.getCurPosition);

    this.mapInstance.on('dragend', this.mapDragend);
    // this.mapInstance.on('moveend', this.mapMoveend);
  },
  beforeDestroy() {
    this.mapInstance.off('dragend', this.mapDragend);
    // this.mapInstance.off('moveend', this.mapMoveend);
    this.geolocation.off('complete', this.getCurPosition)
  },
  methods: {
    // 开启自动定位
    autoPos() {
      this.geolocation.getCurrentPosition((status, result) => {
        console.log('status:'+status)
        console.log('result:'+result)
        if (status === 'complete') {
          // this.$emit('current-position', {
          //   name: result.formattedAddress,
          //   position: result.position
          // })
        } else {
          this.$emit('error');
        }
      });
    },
    // 地图中心点定位
    setMapCenter(position) {
      // debugger;
      this.mapInstance.setCenter([parseFloat(position.lng), parseFloat(position.lat)]);
    },
    // 地图中心点定位并设置缩放度
    setMapZoomAndCenter(zoom, position) {
      this.mapInstance.setZoomAndCenter(zoom, [parseFloat(position.lng), parseFloat(position.lat)]);
    },
    // 搜索周边
    searchAround() {
      // 获取中心点坐标
      const position = this.mapInstance.getCenter();
      const cpoint = [position.lng, position.lat];
      //中心点坐标
      this.placeSearch.searchNearBy('', cpoint, 500, (status, result) => {
        console.log('status1:'+status)
        console.log('result1:'+result)
        if (status === 'complete') {
          const places = result.poiList.pois;
          this.$emit('search-around', places);
          // renderDom.innerHTML = places.map(item => `<li><a data-lat="${item.location.lat}" data-lng="${item.location.lng}">${item.name}</a></li>`).join('')
        } else {
          this.$emit('error');
        }
      });
    },
    // 地图拖动结束事件
    mapDragend() {
      this.mapInstance.on('moveend', this.mapMoveend);
    },
    // 地图移动结束事件
    mapMoveend() {
      this.jump();
      this.$emit('move-end');
      this.mapInstance.off('moveend', this.mapMoveend);
    },
    // 获取当前位置成功后的回调
    getCurPosition(data) {
      // this.$emit('current-position', {
      //   name: data.formattedAddress,
      //   position: data.position
      // });
      this.jump();
      this.$emit('current-position', data);
    },
    // 中点跳动
    jump() {
      this.isJump = true;
    },
    jumpEnd() {
      this.isJump = false;
    }
    // // 滑动事件
    // onTouchMove(event) {
    //   // if (this.showOnly) {
    //     event.preventDefault();
    //   // }
    // }
  },
  computed: {
    placeSearch() {
      return new AMap.PlaceSearch({
        // 兴趣点类别
        type: '汽车服务|汽车销售|汽车维修|摩托车服务|餐饮服务|购物服务|生活服务|体育休闲服务|医疗保健服务|住宿服务|风景名胜|商务住宅|政府机构及社会团体|科教文化服务|交通设施服务|金融保险服务|公司企业|道路附属设施|地名地址信息|公共设施',
        // 单页显示结果条数
        pageSize: this.pagesize,
        // 页码
        pageIndex: this.page,
        // 兴趣点城市
        // city: "0571",
        //是否强制限制在设置的城市内搜索
        citylimit: false,
        // 展现结果的地图实例
        // map: this.mapInstance,
        // 结果列表将在此容器中进行展示。
        // panel: "panel",
        // 是否自动调整地图视野使绘制的 Marker点都处于视口的可见范围
        autoFitView: false
      });
    }
  },
  watch: {
    // defaultPosition(newVal, oldVal) {
    //   // debugger;
    //   this.setMapCenter({
    //     lng: newVal.lng,
    //     lat: newVal.lat
    //   })
    // }
  },
  data() {
    return {
      isJump: false
    }
  }
}
</script>

<style lang="less">
@keyframes jump {
  0% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-12px);
  }
  100% {
    transform: translateY(0);
  }
}

.map-container {
  height: 3rem;
  position: relative;

  .map {
    height: 100%
  }
}
.map-mask {
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: 10;
  left: 0;
  top: 0;
}
.map-center-point {
  position: absolute;
  bottom: 50%;
  left: 50%;
  width: 16px;
  height: 32px;
  margin-left: -8px;
  z-index: 2;

  img {
    width: 100%;
  }
}

.map-jump {
  animation: jump 0.3s ease-in-out 0.1s;
}
</style>
