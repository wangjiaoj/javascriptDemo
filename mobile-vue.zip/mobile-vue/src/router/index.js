import LoginPage from "../pages/login"
import notFoundPage from "../pages/404"

import MainPage from "../pages/main"
import marketMainPage from "../pages/market/main"
import tradeMainPage from "../pages/trade/main"
import centerMainPage from "../pages/center/main"


import marketIndexPage from "../pages/market/index/index"
import centerIndexPage from "../pages/center/index"
import tradeIndexPage from "../pages/trade/index"

import marketMorePage from "../pages/market/index/more"

import VueRouter from "vue-router";
import Vue from 'vue' //注：这句必须要有，虽然在main.js里面已经引入过Vue，但是这里不要这句的话，就直接报错了Vue is not defined
import store from '../store'
Vue.use(VueRouter);
const Foo = () => Promise.resolve({ /* 组件定义对象 */ })


const router = new VueRouter({
    mode: 'history',
    base: '/', //web-app/
    routes: [
        { path: '/', redirect: { name: 'login' }, },
        // 动态路径参数 以冒号开头
        { path: '/login', name: 'login', component: LoginPage },
        {
            path: '/market',
            name: 'market',
            component: marketMainPage,
            redirect: { name: 'marketIndex' },
            children: [{
                    path: 'index',
                    name: 'marketIndex',
                    component: marketIndexPage,
                    children: []
                }, {
                    path: 'more',
                    name: 'marketMoreIndex',
                    component: marketMorePage,
                }

            ]
        },
        {
            path: '/trade',
            name: 'trade',
            component: tradeMainPage,
            redirect: { name: 'tradeIndex' },
            children: [{
                path: 'index',
                name: 'tradeIndex',
                component: tradeIndexPage,
                children: [

                ]
            }]
        }, {
            path: '/center',
            name: 'center',
            component: centerMainPage,
            redirect: { name: 'centerIndex' },
            children: [{
                path: 'index',
                name: 'centerIndex',
                component: centerIndexPage,
                children: [

                ]
            }]
        },
        { path: '*', name: '404', component: notFoundPage },
    ],

});
const whiteList = ["marketIndex", "tradeIndex", "login"];
//全局前置守卫：
router.beforeEach((to, from, next) => {

    if (!to.name || whiteList.includes(to.name)) {
        next();
    } else if (!store.state.token) {
        console.log(to.name)
        console.log(store.state.token)
        next({ name: 'login' }); //重新定向到登录页
    };

});
export default router;