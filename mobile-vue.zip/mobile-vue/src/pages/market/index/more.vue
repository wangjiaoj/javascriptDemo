<template>
    <div class="page-more">
        <div class="market-tab-bar">
            <a href="javascript:;" @click="changeTab(1)"  :class="{'tab-bar-active': 'index' === activeTab}">
                <span>上交</span> 
            </a>
            <a href="javascript:;"  @click="changeTab(2)" :class="{'tab-bar-active': 'commodity' === activeTab}">
            <span>深交</span> 
            </a>
            <a href="javascript:;" @click="changeTab(3)"  :class="{'tab-bar-active': 'stock' === activeTab}"  >
            <span>科创</span> 
            </a>
            <a href="javascript:;"  @click="changeTab(4)"  :class="{'tab-bar-active': 'foreign' === activeTab}"  >
                <span>基金</span> 
            </a>
        </div>
        <div class="page-list">
            <v-list
                :loading="isLoading"
                :finished="isFinished"
                :offset="50"
                finished-text=""
                @load="onLoad"
            >
                <v-list-item
                v-for="(item, index) in listData"
                :key="index"
                :data="item"
                />
            </v-list>
  
        </div>
         
    </div>
</template>
<script>
    import { dataFormat,dataFormatList } from './dataFormat';
    const PAGESIZE = 20;
    export default {
         components:{
             'market-tab': require('../common/market-tab').default,
             'v-list': require('@cc/list').default,
             'v-list-item': require('./item').default,
        },
        data() {
            return {
                activeTab:'index',
                listData: [],
                isFinished: false,
                isLoading: false,
                page: 0, 
                 
                 
            }
        },
        computed: {
            
        },
        methods:{
            changeTab(inex){
                this.isLoading = true;
                this.page += 1;
                
            },
            onLoad(){
               this.$request('/vanish/visitSign/visitSignList', {
                    mkname:'a',//	客户名称  
                    filed:'',
                    order:'', 
                    pageNo: this.page,
                    pageSize: PAGESIZE
                },'post').then(({ rows }) => {
                    this.isLoading = false;
                    this.listData = this.listData.concat(row);
                    //dataFormat(rows)
                    if (rows.length < PAGESIZE) {
                    this.isFinished = true;
                    }
                }, () => {
                    this.isLoading = false;
                    this.isFinished = true;
                });
            }
        }

    }
</script>
<style lang="scss">

</style>