<template lang="html">
  <v-popup
    :value="visible"
    position="bottom"
    @input="close"
  >
    <v-timePicker
      show-toolbar
      :title="title"
      :type="type"
      :min-date="minDate"
      :max-date="maxDate"
      @cancel="close"
      @confirm="onConfirm"
    />
  </v-popup>
</template>

<script>
export default {
  components: {
    'v-popup': require('@cc/popup').default,
    'v-timePicker': require('@cc/timePicker').default
  },
  props: {
    visible: Boolean,
    title: {
      type: String,
      default: '选择日期'
    },
    type: {
      type: String,
      default: 'date'
    },
    minDate: Date,
    maxDate: Date
  },
  methods: {
    close() {
      this.$emit('update:visible', false);
    },
    onConfirm(date) {
      this.$emit('confirm', date);
    }
  }
}
</script>

<style lang="less">
</style>
