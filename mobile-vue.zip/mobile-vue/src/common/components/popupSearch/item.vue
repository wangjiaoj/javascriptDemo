<template lang="html">
  <div class="company-list-item" @click="onClick">
    <span>{{data.name}}</span>
  </div>
</template>

<script>
export default {
  props: {
    data: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  methods: {
    onClick() {
      this.$emit('item-click', this.data);
    }
  },
  computed: {
    showName() {

    }
  }
}
</script>

<style lang="less">
.company-list-item {
  padding: 0.30rem 0;
  margin: 0 0.2rem;
  border-bottom: 1px solid #d9d9d9;
  font-size: 0.24rem;
}
</style>
