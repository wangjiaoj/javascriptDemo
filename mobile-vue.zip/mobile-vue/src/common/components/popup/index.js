import { Popup } from 'vant';

export default Popup;
