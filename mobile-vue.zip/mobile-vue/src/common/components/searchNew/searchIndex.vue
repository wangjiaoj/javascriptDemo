<template>
        <div class="header">
                <div class="hbottom">
                        <i class="searchIcon"></i>
                        <input type="text" v-model="keyword" placeholder="搜索"/>
                </div>
                <div
                        class="search-content"
                        ref="search"
                        v-show="keyword"
                >
                        <ul>
                                <li
                                        class="search-item border-bottom"
                                        @click="contactClick(item.name)"
                                        v-for="item of list"
                                        :key="item.id"
                                >
                                        {{item.name}}
                                </li>
                                <li class="search-item border-bottom" v-show="hasNoData">
                                        没有找到匹配数据
                                </li>
                        </ul>
                </div>
        </div>
</template>

<script>
import BScroll from 'better-scroll'
//   import { mapMutations } from 'vuex'
    export default {
        name: "searchHeader",
        props:{
                listArr : Object
        },
        data(){
            return{
                keyword:"" ,//获取文本框的值
                list:[],//空数组用来存放搜索到的值
                timer: null
            }
        },
        created(){
                console.log('~~~~~')
                console.log(this.listArr)
        },
        methods:{
                
        },
        computed: {
                hasNoData () {
                        return !this.list.length
                }
        },
        watch:{
                keyword () {
                        if (this.timer) {
                                clearTimeout(this.timer)
                        }
                        if (!this.keyword) {
                                this.list = []
                                return
                        }
                        this.timer = setTimeout(() => {
                                const result = []
                                console.log('*****')
                                console.log(this.listArr)
                                for (let i in this.listArr) {
                                        this.listArr[i].forEach((value) => {
                                                if (value.userName.indexOf(this.keyword) > -1) {
                                                        result.push(value)
                                                }
                                        })
                                }
                                this.list = result
                        }, 100)
                }
        },
        mounted () {
                this.scroll = new BScroll(this.$refs.search,{click:true})
        }
}
</script>

<style  lang="less" scoped>
.header{
  width: 100%;
  height: 1rem;
//   background: #00bcd4;
  .htop{
    width: 100%;
    height: 1.162162rem;
    line-height: 1.162162rem;
    color:#fff;
    font-size: 16px;
    text-align: center;
    display: flex;
    a{
        display: block;
        width: 5%;
        height: 1.162162rem;
        line-height: 1.162162rem;
        text-align: center;
        color:#fff;
    }
    h1{
        width: 100%;
        height: 1.162162rem;
        line-height: 1.162162rem;
        text-align: center;
    }
  }
  .hbottom{
    width: 93%;
    height: 0.972972rem;
    line-height: 0.972972rem;
    text-align: center;
    margin-left: 0.3rem;
    .searchIcon{
            position: absolute;
    }
    input{
        width: 98%;
        height: 0.7rem;
        line-height: 0.7rem;
        margin: 0.1rem;
        padding-left: 0.5rem;
        text-align: left;
        border-radius: 5.4px;
        background-color: #eee;
    }
    -webkit-input-placeholder{
            font-size: 14px;
    }

  }
  .search-content{
    z-index: 1111111;
    overflow: hidden;
    position: absolute;
    top: 1.1rem;
    left: 0;
    right: 0;
    bottom: 0;
    background: #eee;
    .search-item{
      line-height:0.62rem;
      padding-left: 0.2rem;
      background: #fff;
      color: #666
    }

  }

}
</style>