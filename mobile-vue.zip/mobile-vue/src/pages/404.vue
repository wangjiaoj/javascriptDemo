<template>
    <div class="error-box">
        404...
    </div>
</template>