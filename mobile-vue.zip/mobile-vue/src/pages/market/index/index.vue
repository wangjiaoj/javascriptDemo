<template>
    <div class="page-index">
        <market-tab activeTab="index"></market-tab>
        <div class="market-tab-bar">
            <a href="javascript:;" @click="changeTab(1)"  :class="{'tab-bar-active': 'index' === activeTab}">
                <span>上交</span> 
            </a>
            <a href="javascript:;"  @click="changeTab(2)" :class="{'tab-bar-active': 'commodity' === activeTab}">
            <span>深交</span> 
            </a>
            <a href="javascript:;" @click="changeTab(3)"  :class="{'tab-bar-active': 'stock' === activeTab}"  >
            <span>科创</span> 
            </a>
            <a href="javascript:;"  @click="changeTab(4)"  :class="{'tab-bar-active': 'foreign' === activeTab}"  >
                <span>基金</span> 
            </a>
        </div>
        <div class="page-title"> 指数行情</div>
      
        <div class="page-hq">
            <div class="hq-item" v-for="(item, index) in hqList" @click="goToHQ(index)">
                <p class="hq-name">{{item.name}}</p> <p class="ha-zs">{{item.zs}}</p>
                <p class="hq-zd"><span>{{item.zdl}}  </span> <span>{{item.zdf}}  </span>    </p> 
            </div>
        </div>
        <div class="page-title">股票排行</div>

        <div class="page-list">
            <div class="page-list-title">
                <span class="stock-name">名称</span><span class="stock-price">最新价</span>
                <span class="stock-zf">涨幅</span><span class="stock-zdf">涨跌幅</span>
            </div>
            <v-list
                :loading="isLoading"
                :finished="isFinished"
                :offset="50"
                finished-text=""
                @load="onLoad"
            >
                <v-list-item
                v-for="(item, index) in listData"
                :key="index"
                :data="item"
                />
            </v-list>
  
        </div>
         
    </div>
</template>
<script>
    import './mockData';
    import { dataFormat,dataFormatList } from './dataFormat';
    const PAGESIZE = 20;
    export default {
         components:{
             'market-tab': require('../common/market-tab').default,
             'v-list': require('@cc/list').default,
             'v-list-item': require('./item').default,
        },
        data() {
            return {
                activeTab:'index',
                listData: [],
                isFinished: false,
                isLoading: false,
                page: 0, 
                hqList:[]
                 
            }
        },
        computed: {
            
        },
        mounted(){
            this.getHQ();
        },
        methods:{
            changeTab(inex){
                this.isLoading = true;
                this.page = 0;
            },
            onLoad(){
               this.page++;
               this.$request('/vanish/visitSign/visitSignList', {
                    mkname:'a',//	客户名称  
                    filed:'',
                    order:'', 
                    pageNo: this.page,
                    pageSize: PAGESIZE
                },'post').then(({ rows }) => {
                    this.isLoading = false;
                    this.listData = this.listData.concat(dataFormat(rows));
                    this.isFinished = true;
                }, () => {
                    this.isLoading = false;
                    this.isFinished = true;
                });
            },
            getHQ(){
                this.$request('/vanish/visitSign/visitSign').then(({ rows }) => {
                  //  this.isLoading = false;
                    this.listData = this.listData.concat(dataFormatList(rows));
                }, () => {
                   // this.isLoading = false;
                });
            },
            goToHQ(){

            }
        }

    }
</script>
<style lang="less">
@import '~@style/init.less';
.page-title{
    .px2rem(font-size, 18);
    .px2rem(height, 45);
    .px2rem(line-height, 45);
    color: #333333;
}
.page-hq{
    .hq-item{
       .px2rem(width, 110);
       .px2rem(height,75);
       background: #FEF7F6;
       .px2rem(font-size, 18);
       .hq-name{
         color: #333333;
       }
        .hq-zs{
           color: #F15A58;
       }
        .hq-zd{
          .px2rem(font-size, 12);
          color: #F15A58;
       }
    }
}
.page-list{
    .page-list-title{
        .px2rem(line-height, 30);
        .px2rem(height,30);
        .px2rem(font-size, 14);
        color: #333333;
        span{
            display: inline-block;
            width:24%;
        }
    }
    
}
</style>