import { Toast } from 'vant';

export default Toast;
