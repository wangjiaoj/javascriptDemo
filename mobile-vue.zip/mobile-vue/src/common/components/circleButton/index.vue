<template lang="html">
  <div
    class="circle-button"
    :class="{'circle-button-disabled': disabled}"
    @click="onClick"
    @touchstart="onTouchStart"
    @touchend="onTouchEnd"
    @touchcancel="onTouchEnd"
  >
    <svg v-show="num > 0" class="circle" viewBox="25 25 50 50">
      <circle
        class="path"
        cx="50"
        cy="50"
        r="23"
        fill="none"
        :style="{stroke: color, strokeWidth: '1px'}"
        :stroke-dasharray='dashArray'
      />
    </svg>
    <div class="circle-button-button" :style="{backgroundColor: color}">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import debounce from '@utils/util/debounce';

export default {
  props: {
    size: String,
    color: String,
    press: {
      type: Boolean,
      default: false
    },
    isLoading: Boolean,
    disabled: Boolean
  },
  created() {
    this.timer = null;
    // this.onTouchStartDebounce = debounce(this.onTouchStart, 300);
  },
  methods: {
    onTouchStart() {
      if (!this.press || this.disabled) return

      this.timer = setInterval(() => {
        if (this.num > 100) {
          this.$emit('touch-a-while');
          this.onTouchEnd();
        } else {
          this.num += 1;
        }
      }, 5);
    },
    onTouchEnd() {
      if (!this.press) return
      // debugger;
      this.num = 0;
      clearInterval(this.timer);
    },
    onClick(event) {
      if (this.disabled) return;

      this.$emit('click', event);
    }
  },
  computed: {
    dashArray: function () {
      //计算周长
      var line = 2 * Math.PI * 23
      return line * (this.num / 100) + ',' + line * ((100 - this.num) / 100);
    }
  },
  data() {
    return {
      num: 0
    }
  }
}
</script>

<style lang="less">
.circle-button {
  position: relative;
  width: 2.8rem;
  height: 2.8rem;
  transition: all 0.24s ease 0s;
  .circle {
    width: 100%;
    height: 100%;
    .path {
      // stroke-dasharray: 90, 150;
      stroke-dashoffset: 35;
    }
  }
}
.circle-button-disabled {
  opacity: 0.5 !important;
}
.circle-button, .circle-button * {
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.circle-button-button {
  width: calc(100% - 0.35rem);
  height: calc(100% - 0.35rem);
  border-radius: 50%;
  // background-color: #449ee9;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  box-shadow: 0 0 10px 3px rgba(0, 0, 0, 0.12);

  &:before {
    content: '';
    position: absolute;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    background-color: rgba(0, 0, 0, 0);
    border-radius: 50%;
    transition: all 0.24s ease 0s;
  }

  &:active:before {
    background-color: rgba(0, 0, 0, 0.12);
  }
}
</style>
