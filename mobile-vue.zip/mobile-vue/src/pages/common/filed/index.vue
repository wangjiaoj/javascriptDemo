<template lang="html">
  <div class="page-field clearfix">
    <span class="page-field-label" :style="{width: labelWidth}">  <label class="page-log-require" v-show="isRequire">*</label>{{label}}</span>
    <div class="page-field-content" :style="{marginLeft: labelWidth}">
      <slot>
        <a @click="onClick" :disabled="disabled">{{linkNameDefault}}</a>
      </slot>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    label: String,
    labelWidth: String,
    linkName: String,
    disabled: Boolean,
    isRequire: Boolean,
  },
  computed: {
    linkNameDefault() {
      return this.linkName || '请选择';
    }
  },
  methods: {
    onClick() {
      if (this.disabled) {
        return;
      }
      this.$emit('click');
    }
  }
}
</script>

<style lang="less">
.page-field {
  padding: 0.3rem 0.2rem 0.3rem;
  border-bottom: 1px solid #eee;
  font-size: 0.3rem;
}
.page-field-label {
  float: left;
  color: #000;
  display: inline-block;
  width: 1.8rem;
}
.page-log-require{
  color: red;
}
.page-field-content {
  margin-left: 1.8rem;
  a {
    color: #006ffe;
  }

  a[disabled] {
    color: #989b9e;
  }

  input, textarea {
    width: 100%;
  }
  .voice-textarea {
    width: 90%;
  }
  .voice-tip {
    float: right;
    width: 0.5rem;
    display: block;
    height: 0.5rem;
    img {
      width: 100%;
      height: 100%;
    }
  }
  span {
    color: #999;
  }
}
</style>
