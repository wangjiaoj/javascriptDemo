<template lang="html">
  <div
    class="stock-item"
    @click="toLogPage"
  >
    
      <div class="stock-name"> <p>{{data.stockName}}</p>  <p>{{data.stockCode}}</p>     </div>
      <div class="stock-price">{{data.price}}</div>
      <div class="stock-zf">{{showTime.substr(0,10)}}</div>
      <div class="stock-zdf">{{data.custName || '--'}}</div>
     
  </div>
</template>

<script>
 

import { dateFormat } from '@utils/dater';

export default {
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  methods: {
    toLogPage() {
      console.log(this.data)
     
    }
  },
  computed: {
    showTime() {  
      return this.data.logDate ? dateFormat(new Date(this.data.logDate), 'yyyy-MM-dd hh:mm:ss') : '';
    }
  }
}
</script>

<style lang="less">
// .stock-item {
//   background-color: #fff;
//   margin: 0 0.2rem 0.16rem;
//   box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.06);
//   padding: 0.2rem 0.5rem 0.2rem 0.2rem;
//   position: relative;
   
// }
@import '~@style/init.less';
.stock-item{
        .px2rem(line-height, 30);
        .px2rem(height,30);
        .px2rem(font-size, 14);
        color: #333333;
        div{
            display: inline-block;
            width:24%
        }
    }
</style>
