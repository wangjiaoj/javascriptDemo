import { DatetimePicker } from 'vant'

export default DatetimePicker;
