<template>
    <ul class="alphabetList">
        <li
          class="letter"
          v-for="item of listArr"
          :key="item"
          :ref="item"
          @click="handeClick"
          @touchstart="handleTouchStart" 
          @touchmove="handleTouchMove" 
          @touchend= "handleTouchEnd"
        >
            {{item}}
        </li>
    </ul>
</template>

<script>
    export default {
        name: "alphabet",
        // 暂时不用父组件数据
        props:{
          list : ""
        },
        data(){
          return{
            bool:false,//标志位
            startY:0,
            heightY:0,  // 单个字母高度
            timer:null
          }
        },
        computed:{
          //定义一个计算属性用于盛放传递过来的值
          listArr () {
              // var str = [];
              // for(var i=65;i<91;i++){
              //     str.push(String.fromCharCode(i));
              // }
              // return str;
            // 根据请求到的数据填写字母表，且排序
            let newArr=[] //定义空数组并循环遍历
            for (let i in this.list) {
              if(this.list[i]){
                newArr.push(i)
              }
            }
            newArr = newArr.sort();
            if(newArr.indexOf('#') > -1){
              let index = newArr.indexOf('#')
              newArr.splice(index,1)
              newArr.push('#')
            }
            console.log(newArr)
            return newArr
          }
        },
       updated(){
         if(this.listArr.length > 0){
            let firstChart = this.listArr[0]
            this.startY=this.$refs[firstChart][0].offsetTop
         }
          
       },
      methods:{
          handeClick(e){
            this.$emit('change',e.target.innerText) //非父子组件传值
          },
          handleTouchStart(){
            // 手指放上去
            this.bool=true
          },
          handleTouchMove(e){
            //在bool的判断为true的时候执行以下判断
            if(this.bool) {

              if(this.timer) {
                clearInterval(this.timer)
              }
              //使用节流函数进行控制
              this.timer = setTimeout(() => {
                console.log(e.touches[0].clientY)
                const touchY = e.touches[0].clientY -100//字母列表 到蓝色头部的距离
                const index = Math.floor((touchY - this.startY ) / 17)
                if(index >=0 && index < this.listArr.length) {
                  console.log('alphabet:'+this.listArr[index])
                  this.$emit('change',this.listArr[index])
                }
              },16)
            }
          },
          handleTouchEnd(){
            // 手指离开
            this.bool=false
          }
      }
    }
</script>

<style scoped lang="less">
.alphabetList{
  position: fixed;
  top: 2rem;
  width: 0.54054rem;
  height: 7rem;
  text-align: center;
  right: 0;
  bottom: 0;
  z-index: 999;
  li{
    width: 100%;
    height: 0.3rem;
    line-height:0.35rem;
    text-align: center;
    color: #25A4BB;
    font-size: 13px;
  }
}
</style>