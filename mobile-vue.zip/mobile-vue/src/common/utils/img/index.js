export function dataURLtoFile(dataurl, filename = 'file') {
  dataurl = dataurl.indexOf(',') > 0 ? dataurl : 'data:image/png;base64,' + dataurl;
  let arr = dataurl.split(',')
  let mime = arr[0].match(/:(.*?);/)[1]
  let suffix = mime.split('/')[1]
  let bstr = atob(arr[1])
  let n = bstr.length
  let u8arr = new Uint8Array(n)
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n)
  }
  return {
    file: new File([u8arr], `${filename}.${suffix}`, {
      type: mime
    }),
    content: dataurl
  };
}
