import { Field } from 'vant';

export default Field;
