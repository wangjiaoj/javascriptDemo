// 去抖函数
export default function(fn, idle) {
  let last;

  return function(...args) {
    clearTimeout(last);

    last = setTimeout(() => {
      fn.call(this, ...args);
    }, idle);
  }
}
