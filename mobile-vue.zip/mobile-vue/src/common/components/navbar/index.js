import { NavBar } from 'vant';

export default NavBar;
