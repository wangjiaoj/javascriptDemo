import Vue from 'vue'
import App from './app'
import router from './router'
import store from './store'
import axios from 'axios'
import PluginToast from '@plugins/toast';
import PluginRequest from '@plugins/request';


import '@style/default.less';

Vue.config.productionTip = false;
Vue.use(PluginToast);
Vue.use(PluginRequest);

new Vue({
    el: "#app",
    router,
    store,
    components: { App },
    template: '<App />'
})