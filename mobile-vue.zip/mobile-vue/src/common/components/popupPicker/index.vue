<template lang="html">
  <v-popup
    :value="visible"
    position="bottom"
    @input="close"
  >
    <v-picker
      show-toolbar
      :title="title"
      :columns="labels"
      @cancel="close"
      @confirm="onConfirm"
    />
  </v-popup>
</template>

<script>
export default {
  components: {
    'v-popup': require('@cc/popup').default,
    'v-picker': require('@cc/picker').default
  },
  props: {
    visible: Boolean,
    title: String,
    options: {
      type: Array,
      default() {
        return []
      }
    },
  },
  methods: {
    close() {
      this.$emit('update:visible', false);
    },
    onConfirm(label, index) {
      this.$emit('confirm', this.options[index]);
    }
  },
  computed: {
    labels() {
      return this.options.map(item => item.label)
    },
    // optionsMaps() {
    //   return this.options.reduce((acc, cur) => {
    //     acc[cur.label] = cur.value;
    //     return acc;
    //   }, {})
    // }
  }
}
</script>

<style lang="less">
</style>
