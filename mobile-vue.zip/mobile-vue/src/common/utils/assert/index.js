import toast from '@cc/toast';

const assertStringMap = {
  'required': function(value) {
    return !!value || value === 0;
  },
  'number': function(value) {
    return typeof value === 'number';
  },
  'arrayNotEmpty': function(value) {
    return Array.isArray(value) && value.length > 0;
  }
}

function ss() {
  return true;
}


function normalize({
  off,
  value,
  validator,
  error
}) {
  let validatorHandler = null;
  let errorHandler = null;

  if (typeof validator === 'string') {
    validatorHandler = assertStringMap[validator] || ss;
  } else if (validator instanceof RegExp) {
    validatorHandler = function() {
      return validator.test(value);
    }
  } else if (typeof validator === 'function') {
    validatorHandler = validator(value);
  } else {
    validatorHandler = ss;
  }

  if (typeof error === 'string') {
    errorHandler = () => toast.fail(error);
  } else if(typeof error === 'function') {
    errorHandler = error;
  } else {
    errorHandler = () => toast.fail('校验失败');
  }

  return {
    off: !!off,
    value,
    validator: validatorHandler,
    error: errorHandler
  }
}


export function valid(arr) {
  const beCheckedList = Array.isArray(arr) ? arr : [];

  for (let i = 0, l = arr.length; i < l; i++) {
    const thisItem = arr[i];
    const opt = normalize(thisItem);

    if (opt.off) {
      return true;
    }

    if (!opt.validator(opt.value)) {
      opt.error();
      return false;
    }
  }

  return true;
}
