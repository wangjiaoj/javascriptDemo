import { Search } from 'vant';

export default Search;
