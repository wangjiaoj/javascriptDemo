<template>
    <div class="page-container">
        <router-view></router-view> 
        <v-tabs activeTab="index"></v-tabs>    
    </div>

</template>
<script>
    export default {
         components:{
             'v-tabs': require('../common/tabs').default,
            
        },
        data() {
            return {}
        }
    }
</script>
<style lang="scss" scoped>
    .page-container {}
    
    .page-body {
        padding: 0px 15px;
    }
    
    .nav-page {
        position: absolute;
        bottom: 0px;
        background: #495060;
        color: #FFF;
        width: 100%;
        ul {
            color: #fff;
            width: 100%;
            display: flex;
            flex-direction: row;
            justify-content: center;
            li {
                line-height: 40px;
                width: 90px;
                a {
                    color: #fff;
                    &:hover {
                        color: #3288fa;
                    }
                }
            }
        }
    }
</style>