module.exports = {
    dev: {
        assetsPublicPath: '/',
    }
}