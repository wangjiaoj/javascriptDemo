export default function checkIOSHistoryBackReload() {
    var u = navigator.userAgent;
    var ua = u.toLowerCase();
    if (/iphone|ipad|ipod/.test(ua)) {
        console.log("iOS");
        window.onpageshow = function(e) {
            console.log("onpageshow");
            if (e.persisted || (window.performance &&
                    window.performance.navigation.type == 2)) {
                window.location.reload();
            }
        }
    }
}