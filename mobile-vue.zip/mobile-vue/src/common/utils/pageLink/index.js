import querystring from 'querystring';

const IS_DEVELOPMENT = process.env.NODE_ENV === 'development';

// 页面跳转
function getHostPath() {
    const loc = window.location;
    return `${loc.protocol}//${loc.host}`;
}

export function anotherPage(pageName) {
    const hostPath = getHostPath();
    const fullPath = hostPath + pageName;

    return {
        url: fullPath,
        goto: function(params, target) {
            const url = `${fullPath}?${querystring.stringify(params)}`;

            if (target === '_blank') {
                window.open(url);
            } else {
                window.location.href = url;
            }
        }
    }
}

// 日志页
export const page_index = anotherPage(IS_DEVELOPMENT ? '/index' : window.ctx + '/vanish/visitSign/visitHomePage');
// 地图页
export const page_map = anotherPage(IS_DEVELOPMENT ? '/map' : window.ctx + '/vanish/visitSign/visitMap');
// 统计页
export const page_stat = anotherPage(IS_DEVELOPMENT ? '/stat' : window.ctx + '/vanish/visitSign/countSignPage');
// 日志页
export const page_log = anotherPage(IS_DEVELOPMENT ? '/log' : window.ctx + '/vanish/visitSign/visitRecordPage');
// 通讯录
export const page_address = anotherPage(IS_DEVELOPMENT ? '/address' : window.ctx + '/vanish/visitSign/addressPage');
// 联系人
export const page_contact = anotherPage(IS_DEVELOPMENT ? '/contact' : window.ctx + '/vanish/visitSign/contactPage');
// 销售助手
export const page_sales = anotherPage(IS_DEVELOPMENT ? '/sales' : window.ctx + '/vanish/visitSign/salesPage');
// 电话统计页 
export const page_telStat = anotherPage(IS_DEVELOPMENT ? '/telStat' : window.ctx + '/vanish/visitSign/telStat');
// 电话日志页 
export const page_telLog = anotherPage(IS_DEVELOPMENT ? '/telLog' : window.ctx + '/vanish/visitSign/telLog');
// 更多页 
export const page_more = anotherPage(IS_DEVELOPMENT ? '/more' : window.ctx + '/vanish/visitSign/morePage');
// 账号管理页 
export const page_accountManage = anotherPage(IS_DEVELOPMENT ? '/accountManage' : window.ctx + '/vanish/accountDelay/vanishCustAccountPage');
// 账号管理页-账号搜索 
export const page_accountSearch = anotherPage(IS_DEVELOPMENT ? '/accountSearch' : window.ctx + '/vanish/accountDelay/vanishCustAccountSearchPage');
// 账号管理页-新开账号 
export const page_accountOpen = anotherPage(IS_DEVELOPMENT ? '/accountOpen' : window.ctx + '/vanish/accountDelay/vanishAccountOpenPage');
// 账号管理页-开通产品 
export const page_accountProductOpen = anotherPage(IS_DEVELOPMENT ? '/accountProductOpen' : window.ctx + '/vanish/accountDelay/vanishAccountOpenProductPage');
// 账号管理页-延期申请 
export const page_applyExtension = anotherPage(IS_DEVELOPMENT ? '/applyExtension' : window.ctx + '/vanish/accountDelay/vanishCustAccountDelayPage');
// 延期申请审核 
export const page_accountAudit = anotherPage(IS_DEVELOPMENT ? '/accountAudit' : window.ctx + '/vanish/accountDelay/vanishAccountAuditPage');
// 延期申请审核详情 
export const page_accountAuditDetail = anotherPage(IS_DEVELOPMENT ? '/accountAuditDetail' : window.ctx + '/vanish/accountDelay/vanishAccountAuditDetailPage');
// 延期申请搜索 
export const page_accountAuditSearch = anotherPage(IS_DEVELOPMENT ? '/accountAuditSearch' : window.ctx + '/vanish/accountDelay/vanishAccountAuditSearchPage');