export default function(data) {
  return Array.isArray(data) ? data.map(item => {
    return {
      name: item.text || '',
      id: item.custSeq + ''
    }
  }) : []
}
