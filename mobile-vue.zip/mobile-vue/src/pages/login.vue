<template>
    <div class="login-page">
         <div class="login-title">登录</div>
         <div class="login-area">
               
            <page-field label="姓名"> <input type="text" name="" value="" placeholder="姓名"></page-field>
            <page-field label="密码"> <input type="password" name="" value="" placeholder="密码"></page-field>
            <div class="login-btn">
               <v-button size="large" type="primary"   @click="doLogin">登录</v-button>
            </div>
             
         </div>
    </div>
</template>
<script>
    export default {
        components:{
             'page-field': require('./common/filed').default,
             'v-button': require('@cc/button').default,
        },
        data() {
            return {

            }
        },
        
        methods: {
            doLogin() {
                this.$store.commit('setToken', 'tttt');
                this.$router.push({
                    name: 'mainCenter'
                });
            }
        }

    }
</script>
<style lang="scss">
    .login-page {
        width: 100vw;
        height:100vh;
    }
    .login-btn{
        width:90%;
        margin:0 auto;
    }
     
</style>