<template lang="html">
  <div class="tab-bar">

    <a href="javascript:;" class="tab-bar-market" :class="{'tab-bar-active': 'market' === activeTab}">
        <router-link to="/market/index"><i></i>  <span>行情</span></router-link> 
    </a>
    <a href="javascript:;" class="tab-bar-trade" :class="{'tab-bar-active': 'trade' === activeTab}">
      <router-link to="/trade/index"><i></i> <span>交易</span></router-link> 
    </a>
    <a href="javascript:;" class="tab-bar-center" :class="{'tab-bar-active': 'center' === activeTab}"  >
       <router-link to="/center/index"><i></i> <span>个人中心</span></router-link> 
    </a>
     
  </div>
</template>

<script>
 
export default {
  props: {
    activeTab: String
  },
  created() {
    
  },
  computed: {
    
     
  },
}
</script>

<style lang="less">
@import '~@style/init.less';

.tab-bar {
  // width: 7.2rem;
  width:100vw;
  position: fixed;
  bottom: 0;
  font-size: 0;
  border-top: 2px solid #f1f1f1;
  z-index: 99;
  display: flex;
  justify-content: space-between;
  background-color: #fff;

  a {
    display: inline-block;
    // width: 42%;
    text-align: center;
    font-size: 0.24rem;
    // padding: 0.20rem 0.3rem 0.24rem;
    padding:0.2rem 0.2rem 0.2rem;
    color: #2196F3;

    i {
      display: block;
      width: 0.5rem;
      height: 0.5rem;
      margin: 0 auto 0.1rem;
      background-repeat: no-repeat;
      background-position: center;
    }
    span {
      color: #999;
    }
  }

  .tab-bar-market {
    i {
      background-image: url('~@images/tab-visit.png');
      background-size: 90%;
    }

    &.tab-bar-active i {
      background-image: url('~@images/tab-visit-active.png');
    }
  }

  .tab-bar-trade{
    i {
      background-image: url('~@images/tab-address.png');
      background-size: 90%;
    }

    &.tab-bar-active i {
      background-image: url('~@images/tab-address-active.png');
    }
  }

  .tab-bar-center {
    i {
      background-size: 100%;
      background-image: url('~@images/tab-stat.png');
    }

    &.tab-bar-active i {
      background-image: url('~@images/tab-stat-active.png');
    }
  }

}
</style>
