<template lang="html">
  <v-popup
    :value="visible"
    position="bottom"
    @input="close"
  >
    <div class="page-search" v-input-focus>
      <v-search
        v-model="inputValue"
        :placeholder="placeholder"
        show-action
        autofocus
        :value="inputValue"
        @input="inputChange"
        @search="onSearch"
        @cancel="close"
      />

      <div class="search-list">
        <v-loading v-show="isLoading" />
        <v-list-item
          v-for="(item, index) in list"
          :key="item.value"
          :data="item"
          @item-click="itemClick"
        />
        <p v-show="!isLoading && list.length <= 0" class="search-list-empty">无相关数据</p>
      </div>
    </div>
  </v-popup>
</template>

<script>
import inputFocus from '@directive/inputFocus';

import debounce from '@utils/util/debounce';

import dataFormat from './dataFormat';


// import './mockData';

export default {
  props: {
    visible: Boolean,
    isLoading: Boolean,
    placeholder: {
      type: String,
      default: ''
    },
    list: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  components: {
    'v-popup': require('@cc/popup').default,
    'v-search': require('@cc/search').default,
    'v-loading': require('@cc/loading'),
    'v-list-item': require('./item')
  },
  directives: {
    'input-focus': inputFocus
  },
  created() {
    this.inputChangeDebounce = debounce(this.inputChangeDebounce, 300);
  },
  mounted() {
  },
  methods: {
    close() {
      this.$emit('update:visible', false);
    },
    onSearch() {

    },
    // 输入框输入事件
    inputChange(value) {
      this.inputValue = value;
      this.$emit('input-change', value);

      this.inputChangeDebounce(value);
    },
    inputChangeDebounce(value) {
      this.$emit('input-change-debounce', value);
    },
    // 点击事件
    itemClick(item) {
      this.$emit('item-click', item);
    }
  },
  data() {
    return {
      inputValue: ''
    }
  }
}
</script>

<style lang="less">
.page-search {
  height: 100vh;
  display: flex;
  flex-direction: column;
}
.search-list {
    flex-grow: 1;
    overflow: auto;
    position: relative;
    -webkit-overflow-scrolling: touch;
}
.search-list-empty {
    text-align: center;
    line-height: 2.0rem;
    font-size: 0.25rem;
    color: #999;
}
</style>
