<template lang="html">
  <div class="loading-wrap">
    <div class="loading-content">
      <v-loading type="spinner" color="white" />
    </div>
  </div>
</template>

<script>
import Loading from '@cc/loadingIn';

export default {
  components: {
    'v-loading': Loading
  }
}
</script>

<style lang="less">
.loading-wrap {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  text-align: center;
}
.loading-content {
  width: 1.2rem;
  height: 1.2rem;
  background: rgba(0, 0, 0, 0.5);
  display: inline-flex;
  justify-content: center;
  align-items: center;
  border-radius: 0.1rem;
  transform: translateY(2rem);
}
</style>
