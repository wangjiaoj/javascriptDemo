import Toast from '@cc/toast';

export default {
  install(Vue) {
    Vue.prototype.$toast = Toast;
  }
}
