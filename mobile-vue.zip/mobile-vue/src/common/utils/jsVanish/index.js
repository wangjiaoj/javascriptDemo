// 是否是开发环境
const isDevelopment = process.env.NODE_ENV === 'development';
import { dateFormat } from '@utils/dater';
if (isDevelopment) {
    window.jsVanish = {
        signStringMethod() {
            return '';
        },
        getVanishUserInfo() {
            return '{}';
        },
        queryGPSInfo(str) {
            window[str](30.294671, 120.041238);
        },
        scanDocument(str) {
            window[str](0, `iVBORw0KGgoAAAANSUhEUgAAACEAAAAkCAYAAAAHKVPcAAAAAXNSR0IArs4c6QAAAZVJREFUWAnt1kFKAzEUBuCXcZqVgkJXglg8gngABd0JIgiewEvoZhbiyqu4cK2gBxCv4OhKoaCCG7tofC82ZabOdF7mkczGwJCU8r98k5SkAP/tdwVU/9RcGoD1JQ0neaY+fBZGki3Ok4CBA3yOvkZwM8jMcvHLxrEkWyiegIJj/PxuDGx5QyTZAkLRGJd1ExG3OFxRCh4WNexxt0aSdQ6L6BoyRXQJKSG6gvxBdAGpRMSG1CJiQuYiYkEaETEgLERoCBsREuKFCAXxRoSAJFTUtw0v1CNedLuYc7fvNbdGVbYVgibUGobYfdIY/xT1qee22WwrxOqZWRt9wx1OOsDnJU1gnwuoynr/JmyRMdzj229YwAJsv52rJw6iLuuFqCsiAVCWjQgFYCNCAliI0IBGRAzAXEQsQC0iJqASUQIoeMaDaKfVOeCRLZ2Ys4CebnkQIcAnOz0nqgCvmcppuZqaJEu1LUJSRJJ1L6ckRSRZB6A+GY3hyl5Gk33kbgGFJVnKu5bihuS4J71Uw6EPwBaQZJ0A+x9LABkYqHK/nQAAAABJRU5ErkJggg==`, 0);
        },
        getCallRecord(phone, callDayTime) {
            var randomNumber = parseInt(Math.random() * 10);
            var time1 = Date.parse(new Date()) - 60 * 60;
            time1 = dateFormat(new Date(parseInt(time1)), 'yyyy-MM-dd hh:mm:ss');
            time1 = Date.parse(new Date(time1)) / 1000;
            var time2 = Date.parse(new Date()) - 60 * 60 * 2;
            time2 = dateFormat(new Date(parseInt(time2)), 'yyyy-MM-dd hh:mm:ss');
            time2 = Date.parse(new Date(time2)) / 1000;
            var recordList = [{ "phone": phone, "name": "张三", "startTime": time1, "duration": 0, "state": 1 },
                { "phone": phone, "name": "张二", "startTime": time2, "duration": 9, "state": 1 }
            ];
            if ((randomNumber % 2) == 1) {
                recordList = JSON.stringify(recordList);
            } else {
                recordList = '';
            }
            return recordList;
        },
        //请求获取通话记录权限
        requestCallRecordPermission() {

        }
    };
}