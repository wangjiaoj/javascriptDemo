<template lang="html">
  <van-checkbox-group :value="value" @input="v => $emit('input', v)">
    <van-cell-group>
      <van-cell
        v-for="(item, index) in options"
        clickable
        :key="item.value"
        :title="item.label"
        @click="toggle(item.value)"
      >
        <van-checkbox :name="item.value" ref="checkboxes"/>
      </van-cell>
    </van-cell-group>
  </van-checkbox-group>
</template>

<script>
import { CheckboxGroup, CellGroup, Cell, Checkbox } from 'vant';

export default {
  components: {
    'van-checkbox-group': CheckboxGroup,
    'van-cell-group': CellGroup,
    'van-cell': Cell,
    'van-checkbox': Checkbox
  },
  props: {
    value: {
      type: Array,
      default() {
        return []
      }
    },
    options: {
      type: Array,
      default() {
        return []
      }
    }
  },
  methods: {
    toggle(index) {
      this.$refs.checkboxes.find((item) => item.name === index).toggle()
    }
  },
  watch: {
    result(newVal) {
      console.log(newVal)
    }
  }
}
</script>

<style lang="css" scoped>
</style>
