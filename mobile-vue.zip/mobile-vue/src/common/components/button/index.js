import { Button } from 'vant';

import './index.less';

export default Button;
