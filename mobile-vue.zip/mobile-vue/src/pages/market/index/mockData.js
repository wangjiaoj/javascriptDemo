import { Mock, Random, wrap } from '@mock';
//行情
Mock.mock(/\/vanish\/visitSign\/visitSign/, wrap({
    'rows|20': [{
        // 签到的seq
        '5|+1': 1,
        // 拜访记录的seq 只记录最近一条
        '10|+1': 1000,
        // 日期
        '55|+1': 1000,
        // 客户seq 客户主键
        '199112|+1': 10000,
        // 客户seq 客户主键
        '2558408|+1': 10000,
        // 拜访状态 Type=0开始拜访；type=1结束拜访
        // status: () => Random.natural(0, 1),
        // 客户名称
        // custName: () => Random.cword(5, 10),

    }]
}));
Mock.mock(/\/vanish\/visitSign\/visitSignList/, wrap({
    'rows|20': [{
        // 签到的seq
        '5|+1': 1,
        // 拜访记录的seq 只记录最近一条
        '10|+1': 1000,
        // 日期
        '55|+1': 1000,
        // 客户seq 客户主键
        '199112|+1': 10000,
        // 客户seq 客户主键
        '2558408|+1': 10000,
        // 拜访状态 Type=0开始拜访；type=1结束拜访
        // status: () => Random.natural(0, 1),
        // 客户名称
        // custName: () => Random.cword(5, 10),

    }]
}));