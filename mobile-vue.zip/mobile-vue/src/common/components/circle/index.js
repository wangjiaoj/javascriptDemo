import { Circle } from 'vant';

export default Circle;
