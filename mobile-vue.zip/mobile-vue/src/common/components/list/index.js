import { List } from 'vant';

import './index.less';

export default List;
